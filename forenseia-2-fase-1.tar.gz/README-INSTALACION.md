# ForenseIA 2.0 — primera fase pública

Este paquete implementa la primera fase visual y estratégica de ForenseIA 2.0:

- Home organizada por institutos.
- Academia, biblioteca y Gaceta conectadas.
- Header responsive.
- Footer institucional.
- Design system global.
- SEO base en el layout.

## Archivos reemplazados

- `src/pages/index.astro`
- `src/layouts/BaseLayout.astro`
- `src/components/layout/Header.astro`
- `src/components/layout/Footer.astro`
- `src/components/ui/Button.astro`
- `src/components/ui/Container.astro`
- `src/styles/global.css`

## Instalación

Desde la raíz del proyecto:

```bash
cp -r src src-backup-forenseia-2

tar -xzf forenseia-2-fase-1.tar.gz

rm -rf .astro dist
npm run build
npm run dev
```

El código conserva `/logo.png` y el componente existente `WhatsAppFloat.astro`.

## Nota

Esta fase no crea todavía un LMS, CRM ni membresías. Organiza la parte pública para que los cursos, recursos, servicios y artículos existentes se presenten como un ecosistema comercial coherente.
